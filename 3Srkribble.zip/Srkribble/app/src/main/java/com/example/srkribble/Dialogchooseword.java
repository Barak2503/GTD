package com.example.srkribble;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.ExecutionException;

public class Dialogchooseword extends Dialog implements View.OnClickListener {
    Button btnWord1,btnWord2,btnWord3;
    private WordAPI wordAPI;

    Context context;

    public Dialogchooseword(@NonNull Context context , String wa, String wb, String wc) {
        super(context);
        setContentView(R.layout.dialogchooseword);
        this.context=context;



        btnWord1=findViewById(R.id.word1btn);
        btnWord2=findViewById(R.id.word2btn);
        btnWord3=findViewById(R.id.word3btn);

        wordAPI = new WordAPI();
        String[] arr = wordAPI.getWord();
        wa=arr[0];
        wb=arr[1];
        wc=arr[2];

        btnWord1.setText(wa);
        btnWord2.setText(wb);
        btnWord3.setText(wc);

        btnWord3.setOnClickListener(this);
        btnWord2.setOnClickListener(this);
        btnWord1.setOnClickListener(this);

    }

    @Override
    public void onClick(View v)
    {
        if(v==btnWord1);
        {
            Intent word=new Intent(context, CanvasActivity.class);
            word.putExtra("word",btnWord1.getText());
            ((CanvasActivity)context).startActivity(word);

        }
        if(v==btnWord2);
        {
            Intent word=new Intent(context, CanvasActivity.class);
            word.putExtra("word",btnWord2.getText());
            ((CanvasActivity)context).startActivity(word);

        }
        if(v==btnWord3);
        {
            Intent word=new Intent(context, CanvasActivity.class);
            word.putExtra("word",btnWord3.getText());
            ((CanvasActivity)context).startActivity(word);
        }
    }
}
