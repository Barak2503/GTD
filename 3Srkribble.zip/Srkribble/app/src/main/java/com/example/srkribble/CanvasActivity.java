package com.example.srkribble;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.PersistableBundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class CanvasActivity extends AppCompatActivity {

    Button btnGuess;
    EditText etGuess;
    TextView tvP1name,tvP2name,tvP3name,tvP4name,tvTimer;
    Player p1,p2,p3,p4;
    String player1,player2,player3,player4;
    int players;
    public Handler handler;

    private BoardGame boardGame;
    private int a;

    private WordAPI wordAPI;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
        boardGame = new BoardGame(this);
        setContentView(boardGame);
        btnGuess=findViewById(R.id.btnGuess);
        etGuess=findViewById(R.id.etGuess);
        tvP1name=findViewById(R.id.tvP1name);
        tvP2name=findViewById(R.id.tvP2name);
        tvP3name=findViewById(R.id.tvP3name);
        tvP4name=findViewById(R.id.tvP4name);
        tvTimer=findViewById(R.id.timer);

        Threads threads = new Threads(this, handler);
        a = 0;
        handler = new Handler(new Handler.Callback() {
            @Override
            public boolean handleMessage(@NonNull Message msg) {
                a++;
                tvTimer.setText(a);
                return false;
            }
        });


        Intent Ip1 =getIntent();
        Intent Ip2 =getIntent();
        Intent Ip3 =getIntent();
        Intent Ip4 =getIntent();
        Intent Num = getIntent();

        players=Num.getIntExtra("Playernumber",0);
        player1= Ip1.getStringExtra("p1");
        player2=Ip2.getStringExtra("p2");
        player3=Ip3.getStringExtra("p3");
        player4=Ip4.getStringExtra("p4");
        p1.setplayer(player1);
        p2.setplayer(player2);
        p3.setplayer(player3);
        p4.setplayer(player4);

        /*tvP1name.setText(p1.getName()+ "\n" +"Score:"+" "+p1.getScore());
        tvP1name.setText(p2.getName()+ "\n" +"Score:"+" "+p2.getScore());
        tvP1name.setText(p3.getName()+ "\n" +"Score:"+" "+p3.getScore());
        tvP1name.setText(p4.getName()+ "\n" +"Score:"+" "+p4.getScore());*/

        if(players==4)
        {
            tvP1name.setText(p1.getName()+ "\n" +"Score:"+" "+p1.getScore());
            tvP2name.setText(p2.getName()+ "\n" +"Score:"+" "+p2.getScore());
            tvP3name.setText(p3.getName()+ "\n" +"Score:"+" "+p3.getScore());
            tvP4name.setText(p4.getName()+ "\n" +"Score:"+" "+p4.getScore());
        }
        if(players==3)
        {
            if(p1.isReady()==false)
            {
                tvP2name.setText(p2.getName()+ "\n" +"Score:"+" "+p2.getScore());
                p2.setNumber(1);
                tvP3name.setText(p3.getName()+ "\n" +"Score:"+" "+p3.getScore());
                p3.setNumber(2);
                tvP4name.setText(p4.getName()+ "\n" +"Score:"+" "+p4.getScore());
                p4.setNumber(3);

            }
            if(p2.isReady()==false)
            {
                tvP1name.setText(p1.getName()+ "\n" +"Score:"+" "+p1.getScore());
                tvP3name.setText(p3.getName()+ "\n" +"Score:"+" "+p3.getScore());
                p3.setNumber(2);
                tvP4name.setText(p4.getName()+ "\n" +"Score:"+" "+p4.getScore());
                p4.setNumber(3);
            }
            if(p3.isReady()==false)
            {
                tvP1name.setText(p1.getName()+ "\n" +"Score:"+" "+p1.getScore());
                tvP2name.setText(p2.getName()+ "\n" +"Score:"+" "+p2.getScore());
                tvP4name.setText(p4.getName()+ "\n" +"Score:"+" "+p4.getScore());
                p4.setNumber(3);
            }
            if(p4.isReady()==false)
            {
                tvP1name.setText(p1.getName()+ "\n" +"Score:"+" "+p1.getScore());
                tvP2name.setText(p2.getName()+ "\n" +"Score:"+" "+p2.getScore());
                tvP3name.setText(p3.getName()+ "\n" +"Score:"+" "+p3.getScore());
            }

        }
        if(players==2)
        {
            if(p1.isReady()==false&& p2.isReady()==false)
            {
                tvP3name.setText(p3.getName()+ "\n" +"Score:"+" "+p3.getScore());
                p3.setNumber(1);
                tvP4name.setText(p4.getName()+ "\n" +"Score:"+" "+p4.getScore());
                p4.setNumber(2);
            }
            if(p1.isReady()==false&& p3.isReady()==false)
            {
                tvP2name.setText(p2.getName()+ "\n" +"Score:"+" "+p2.getScore());
                p2.setNumber(1);
                tvP4name.setText(p4.getName()+ "\n" +"Score:"+" "+p4.getScore());
                p4.setNumber(2);
            }
            if(p1.isReady()==false&& p4.isReady()==false)
            {
                tvP2name.setText(p2.getName()+ "\n" +"Score:"+" "+p2.getScore());
                p2.setNumber(1);
                tvP3name.setText(p3.getName()+ "\n" +"Score:"+" "+p3.getScore());
                p3.setNumber(2);
            }
            if(p2.isReady()==false&& p3.isReady()==false)
            {
                tvP1name.setText(p1.getName()+ "\n" +"Score:"+" "+p1.getScore());
                tvP4name.setText(p4.getName()+ "\n" +"Score:"+" "+p4.getScore());
                p4.setNumber(2);
            }
            if(p2.isReady()==false&& p4.isReady()==false)
            {
                tvP1name.setText(p1.getName()+ "\n" +"Score:"+" "+p1.getScore());
                tvP3name.setText(p3.getName()+ "\n" +"Score:"+" "+p3.getScore());
                p3.setNumber(2);
            }
            if(p3.isReady()==false&& p4.isReady()==false)
            {
                tvP2name.setText(p2.getName()+ "\n" +"Score:"+" "+p2.getScore());
                tvP1name.setText(p1.getName()+ "\n" +"Score:"+" "+p1.getScore());
            }
        }
         int rounds=players*2;



    }

    public void dataChange() {
        boardGame.dataChange();

    }



}
