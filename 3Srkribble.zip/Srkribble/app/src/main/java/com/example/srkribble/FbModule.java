package com.example.srkribble;

import android.content.Context;

import androidx.annotation.NonNull;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class FbModule {

    FirebaseDatabase database;
    Context context;
    ArrayList<Ball> balls;

    public FbModule(Context context)
    {
        //database = FirebaseDatabase.getInstance();
        database = FirebaseDatabase.getInstance("https://srkribblefb-default-rtdb.europe-west1.firebasedatabase.app/");

        this.context = context;
        this.balls = balls;

        /*DatabaseReference reference = database.getReference("balls");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                balls.clear();
                for (DataSnapshot userSnapshot : snapshot.getChildren())
                {
                    Ball currentBall = userSnapshot.getValue(Ball.class);
                    balls.add(currentBall);
                }
                ((CanvasActivity)context).dataChange();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });*/


        DatabaseReference reference2=database.getReference("buttons");
        reference2.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                ArrayList<Integer> newList = new ArrayList<>();

                // בדיקה אם הנתונים קיימים
                if (snapshot.exists()) {
                    // לולאה על כל הילדים של הצומת "buttons"
                    for (DataSnapshot data : snapshot.getChildren()) {
                        Integer value = data.getValue(Integer.class); // המרת הערך ל-INT
                        if (value != null) {
                            newList.add(value); // הוספת הערך ל-ArrayList
                        }
                    }
                }
                ((LobbyActivity)context).update(newList);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    public void setBall(int x, int y, int r, int color)
    {
        Ball ball = new Ball(x,y,r,color);

        DatabaseReference myRef = database.getReference("balls").push();
        myRef.setValue(ball);
    }

    public void FBplayers(Context context, ArrayList<Integer> buttons)
    {
        database = FirebaseDatabase.getInstance("https://srkribblefb-default-rtdb.europe-west1.firebasedatabase.app/");
        this.context=context;
        DatabaseReference reference=database.getReference("buttons");
        //reference.setValue("buttons");
        reference.setValue(buttons);

    }
}
