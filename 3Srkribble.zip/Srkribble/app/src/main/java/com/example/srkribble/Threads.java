package com.example.srkribble;

import android.content.Context;
import android.os.Handler;

public class Threads extends Thread
{
    private Handler handler;

    public Threads(Context context, Handler handler)
    {
        this.handler = ((CanvasActivity)context).handler;

    }

    @Override
    public void run() {
        super.run();
        while (true)
        {
            try
            {
                Thread.sleep(1000);
                handler.sendEmptyMessage(1);
            }
            catch (InterruptedException e)
            {
                throw new RuntimeException(e);
            }
        }
    }
}
