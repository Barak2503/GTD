package com.example.srkribble;

public class Player
{
    private int score;
    private int number;
    private String name;
    private boolean isReady;

    public Player() {
        this.score = 0;
        this.number = 0;
        this.name = "";
        this.isReady = false;
    }
    @Override
    public String toString() {
        return  name +"," + number+","+isReady;
    }


    public int getScore() {
        return score;
    }

    public void setplayer(String string)
    {
        Player p1=new Player();
        p1.setScore(0);
        String[]parts = string.split(",");
        p1.setName(parts[1]);
        p1.setNumber(Integer.valueOf(parts[2]));
        p1.setReady(Boolean.valueOf(parts[3]));

    }

    public void setScore(int score) {
        this.score = score;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isReady() {
        return isReady;
    }

    public void setReady(boolean ready) {
        isReady = ready;
    }

}
