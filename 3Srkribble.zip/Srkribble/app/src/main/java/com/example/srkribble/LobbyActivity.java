package com.example.srkribble;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class LobbyActivity extends AppCompatActivity implements View.OnClickListener {
    Button btnP1, btnP2, btnP3, btnP4, btnReady;
    String name;
    Player p1, p2, p3, p4;
    private FbModule fbModule;
    private String userId;

    int count = 0, count1 = 0, count2 = 0, count3 = 0, count4 = 0;
    private int myPlayer;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lobby);
        fbModule = new FbModule(this);


        btnP1 = findViewById(R.id.btnP1);
        btnP2 = findViewById(R.id.btnP2);
        btnP3 = findViewById(R.id.btnP3);
        btnP4 = findViewById(R.id.btnP4);
        btnReady = findViewById(R.id.btnReady);
        p1 =new Player();
        p2 =new Player();
        p3 =new Player();
        p4 =new Player();


        btnP1.setOnClickListener(this);
        btnP2.setOnClickListener(this);
        btnP3.setOnClickListener(this);
        btnP4.setOnClickListener(this);
        btnReady.setOnClickListener(this);
        Intent i = getIntent();
        name = i.getStringExtra("name");//USERID

        fbModule.FBplayers(this,null);
    }

    @Override
    public void onClick(View v) {
        if (v == btnP1 && btnP1.getText().equals("Empty")) {
            myPlayer = 1;
            btnP1.setText(name);
            p1.setNumber(1);
            p1.setName(btnP1.getText().toString());
            btnP1.setTextColor(Color.RED);
            btnP2.setClickable(false);
            btnP3.setClickable(false);
            btnP4.setClickable(false);
            count++;
            createlist(myPlayer);

        }
        if (v == btnP2 && btnP2.getText().equals("Empty")) {
            myPlayer = 2;
            btnP2.setText(name);
            p2.setNumber(2);
            p2.setName(btnP2.getText().toString());
            btnP2.setTextColor(Color.RED);
            btnP1.setClickable(false);
            btnP3.setClickable(false);
            btnP4.setClickable(false);
            count++;
            createlist(myPlayer);
        }
        if (v == btnP3 && btnP3.getText().equals("Empty")) {
            btnP3.setText(name);
            p3.setNumber(3);
            myPlayer=3;
            p3.setName(btnP3.getText().toString());
            btnP3.setTextColor(Color.RED);
            btnP2.setClickable(false);
            btnP1.setClickable(false);
            btnP4.setClickable(false);
            count++;
            createlist(myPlayer);
        }
        if (v == btnP4 && btnP4.getText().equals("Empty")) {
            btnP4.setText(name);
            myPlayer=4;
            p4.setNumber(4);
            p4.setName(btnP4.getText().toString());
            btnP4.setTextColor(Color.RED);
            btnP2.setClickable(false);
            btnP3.setClickable(false);
            btnP1.setClickable(false);
            count++;
            createlist(myPlayer);
        }
        if (!p1.getName().equals("")&&v == btnReady&&myPlayer==1) {
            if (!p1.isReady()) {
                p1.setReady(true);
            } else {
                p1.setReady(false);
            }
            count1++;
            if(count1%2==1)
            {
                btnP1.setTextColor(Color.GREEN);
            }
            else{
                btnP1.setTextColor(Color.RED);
            }


        }
        if (!p2.getName().equals("")&& v == btnReady&&myPlayer==2) {
            if (!p2.isReady()) {
                p2.setReady(true);
            } else {
                p2.setReady(false);
            }
            count2++;
            if(count2%2==1)
            {
                btnP2.setTextColor(Color.GREEN);
            }
            else{
                btnP2.setTextColor(Color.RED);
            }


        }
        if (!p3.getName().equals("")&&v == btnReady&&myPlayer==3) {
            if (!p3.isReady()) {
                p3.setReady(true);
            } else {
                p3.setReady(false);
            }
            count3++;
            if(count3%2==1)
            {
                btnP3.setTextColor(Color.GREEN);
            }
            else{
                btnP3.setTextColor(Color.RED);
            }


        }
        if (!p4.getName().equals("")&&v==btnReady&&myPlayer==4) {
            if (!p4.isReady()) {
                p4.setReady(true);
            } else {
                p4.setReady(false);
            }
            count4++;
            if(count4%2==1)
            {
                btnP4.setTextColor(Color.GREEN);
            }
            else{
                btnP4.setTextColor(Color.RED);
            }


        }
        if (2<=count) {
              Intent stats = new Intent(this, LobbyActivity.class);
            if (count1 % 2 == 1 && count2 % 2 == 1 && count3 % 2 == 0 && count4 % 2 == 0 ||
                    count1 % 2 == 1 && count2 % 2 == 0 && count3 % 2 == 1 && count4 % 2 == 0 ||
                    count1 % 2 == 1 && count2 % 2 == 0 && count3 % 2 == 0 && count4 % 2 == 1 ||
                    count1 % 2 == 0 && count2 % 2 == 0 && count3 % 2 == 1 && count4 % 2 == 1 ||
                    count1 % 2 == 0 && count2 % 2 == 1 && count3 % 2 == 1 && count4 % 2 == 0 ||
                    count1 % 2 == 0 && count2 % 2 == 1 && count3 % 2 == 0 && count4 % 2 == 1) {

                if (count1 % 2 == 1 && count2 % 2 == 1 && count3 % 2 == 0 && count4 % 2 == 0) {
                    stats.putExtra("p1",p1.toString());
                    stats.putExtra("p2",p2.toString());
                    stats.putExtra("p3",p3.toString());
                    stats.putExtra("p4",p4.toString());
                    stats.putExtra("Playernumber",count);
                    startActivity(stats);


                }
                if (count1 % 2 == 1 && count2 % 2 == 0 && count3 % 2 == 1 && count4 % 2 == 0) {
                    stats.putExtra("p1",p1.toString());
                    stats.putExtra("p2",p2.toString());
                    stats.putExtra("p3",p3.toString());
                    stats.putExtra("p4",p4.toString());
                    stats.putExtra("Playernumber",count);
                    startActivity(stats);

                }
                if (count1 % 2 == 1 && count2 % 2 == 0 && count3 % 2 == 0 && count4 % 2 == 1) {
                    stats.putExtra("p1",p1.toString());
                    stats.putExtra("p2",p2.toString());
                    stats.putExtra("p3",p3.toString());
                    stats.putExtra("p4",p4.toString());
                    stats.putExtra("Playernumber",count);
                    startActivity(stats);



                }
                if (count1 % 2 == 0 && count2 % 2 == 1 && count3 % 2 == 1 && count4 % 2 == 0) {
                    stats.putExtra("p1",p1.toString());
                    stats.putExtra("p2",p2.toString());
                    stats.putExtra("p3",p3.toString());
                    stats.putExtra("p4",p4.toString());
                    stats.putExtra("Playernumber",count);
                    startActivity(stats);


                }
                if (count1 % 2 == 0 && count2 % 2 == 0 && count3 % 2 == 1 && count4 % 2 == 1) {
                    stats.putExtra("p1",p1.toString());
                    stats.putExtra("p2",p2.toString());
                    stats.putExtra("p3",p3.toString());
                    stats.putExtra("p4",p4.toString());
                    stats.putExtra("Playernumber",count);
                    startActivity(stats);

                }
                if (count1 % 2 == 0 && count2 % 2 == 1 && count3 % 2 == 0 && count4 % 2 == 1) {
                    stats.putExtra("p1",p1.toString());
                    stats.putExtra("p2",p2.toString());
                    stats.putExtra("p3",p3.toString());
                    stats.putExtra("p4",p4.toString());
                    stats.putExtra("Playernumber",count);
                    startActivity(stats);

                }

            }
            if(count==3) {
                if (count1 % 2 == 1 && count2 % 2 == 1 && count3 == 1 & count4 % 2 == 0
                        || count1 % 2 == 0 && count2 % 2 == 1 && count3 % 2 == 1 && count4 == 1
                        || count1 % 2 == 1 && count2 % 2 == 1 && count3 % 2 == 0 && count4 % 3 == 1
                        || count1 % 2 == 1 && count2 % 2 == 0 && count3 % 2 == 1 && count4 % 3 == 1) {
                    if(count1 % 2 == 1 && count2 % 2 == 1 && count3 == 1 & count4 % 2 == 0)
                    {
                        stats.putExtra("p1",p1.toString());
                        stats.putExtra("p2",p2.toString());
                        stats.putExtra("p3",p3.toString());
                        stats.putExtra("p4",p4.toString());
                        stats.putExtra("Playernumber",count);
                        startActivity(stats);
                    }
                    if(count1 % 2 == 0 && count2 % 2 == 1 && count3 == 1 & count4 % 2 == 1)
                    {
                        stats.putExtra("p1",p1.toString());
                        stats.putExtra("p2",p2.toString());
                        stats.putExtra("p3",p3.toString());
                        stats.putExtra("p4",p4.toString());
                        stats.putExtra("Playernumber",count);
                        startActivity(stats);
                    }
                    if(count1 % 2 == 1 && count2 % 2 == 1 && count3 == 0 & count4 % 2 == 1)
                    {
                        stats.putExtra("p1",p1.toString());
                        stats.putExtra("p2",p2.toString());
                        stats.putExtra("p3",p3.toString());
                        stats.putExtra("p4",p4.toString());
                        stats.putExtra("Playernumber",count);
                        startActivity(stats);
                    }
                    if(count1 % 2 == 1 && count2 % 2 == 0 && count3 == 1 & count4 % 2 == 4)
                    {
                        stats.putExtra("p1",p1.toString());
                        stats.putExtra("p2",p2.toString());
                        stats.putExtra("p3",p3.toString());
                        stats.putExtra("p4",p4.toString());
                        stats.putExtra("Playernumber",count);
                        startActivity(stats);
                    }
                }
            }
            if(count==4)
            {
                if(count1%2==1&&count2%2==1&&count3%2==1&&count4%2==1)
                {
                    stats.putExtra("p1",p1.toString());
                    stats.putExtra("p2",p2.toString());
                    stats.putExtra("p3",p3.toString());
                    stats.putExtra("p4",p4.toString());
                    stats.putExtra("Playernumber",count);
                    startActivity(stats);

                }
            }

        }

    }

    private void createlist(int myPlayer) {
        ArrayList<Integer> list = new ArrayList<Integer>();
        list.add(100);
        for (int i = 1; i <= 4; i++) {
            if(myPlayer == i){
                list.add(1);
            }
            else{
                list.add(0);
            }
        }
        fbModule.FBplayers(this,list);
    }

    public void update(ArrayList<Integer> newList) {
        for (int i = 1; i < newList.size(); i++) {
            if(newList.get(i)==1){
                if(i==1){
                    btnP1.setClickable(false);
                }
                if(i==2){
                    btnP2.setClickable(false);
                }
                if(i==3){
                    btnP3.setClickable(false);
                }
                if(i==4){
                    btnP4.setClickable(false);
                }
            }
        }
    }
}
