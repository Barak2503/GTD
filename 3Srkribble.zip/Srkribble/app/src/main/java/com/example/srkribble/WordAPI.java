package com.example.srkribble;

import android.os.AsyncTask;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.ExecutionException;

//      :D
public class WordAPI {

    String random5LetterWord = "https://random-word-api.herokuapp.com/word?length=5";
    String random10Words = "https://random-word-api.herokuapp.com/word?number=3";

    public class DownloanJson extends AsyncTask<String,Void,String>{

        @Override
        protected String doInBackground(String... strings) {
            String result = "";
            URL url;
            HttpURLConnection httpURLConnection;
            InputStream inputStream;
            InputStreamReader inputStreamReader;

            try {
                url = new URL(strings[0]);

                httpURLConnection = (HttpURLConnection) url.openConnection();
                inputStream = httpURLConnection.getInputStream();
                inputStreamReader = new InputStreamReader(inputStream);
                int data = inputStreamReader.read();
                while (data != -1)
                {
                    result += (char)data;
                    data = inputStreamReader.read();
                }

            } catch (MalformedURLException e) {
                throw new RuntimeException(e);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

            return result;
        }
    }


    protected String[] getWord() {


        //TextView tv1 = findViewById(R.id.tv1);
        //TextView tv2 = findViewById(R.id.tv2);

        DownloanJson downloanJson = new DownloanJson();
        String result = null;

        String url = random5LetterWord;
        url = random10Words;

        try {
            result = downloanJson.execute(url).get();
        } catch (ExecutionException e) {
            throw new RuntimeException(e);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        //tv1.setText(result);

        String str = result.substring(1,result.length()-1); // throw the []
        String[] arr = str.split(",");
        //tv2.setText(arr[2]);
        return arr;

    }
}