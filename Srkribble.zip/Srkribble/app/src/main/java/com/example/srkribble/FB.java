package com.example.srkribble;

import android.content.Context;

import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class FB
{
FirebaseDatabase database;
Context context;

ArrayList<Player>players;


}
