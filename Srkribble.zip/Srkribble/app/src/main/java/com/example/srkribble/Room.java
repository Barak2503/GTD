package com.example.srkribble;

import android.graphics.Canvas;

public class Room
{
    private Canvas canvas;
    private Player p1,p2,p3,p4;

}
