package com.example.srkribble;

public class Player
{
    private int score;
    private int number;
    private String name;
    private boolean isReady;
}
